---
name: methods-repro-audit
description: 从配置、日志、代码里抽参数并与方法章节正文逐项对齐，标出无源数值与冲突值，再按"步骤四要素 + 复现清单九项"检查章节能否被他人复做。用于方法与实验章节写作，避免为段落顺畅补数值。
---

# 方法与实验章节：参数对齐与可复现

## 0. 单点

**每一个写进正文的数值都要有来源**（配置/日志/代码/作者确认），**每一个步骤都要有输入-操作-输出-判断**，**复现清单九项齐全**。三者任一缺失，章节就是"能读通但不能复做"。

## 1. 何时触发

"补方法章节""实验设置怎么写""参数从哪来""复现不了""审稿人说缺细节"。
不触发：纯翻译、纯润色、摘要、结果讨论改写。

## 2. 输入与输出

输入：`/input/case.json`、`/input/task.md`、实验材料（配置文件、运行日志、代码片段、数据说明、作者口述）。
先列材料清单，**没读到的文件不许猜内容**。

输出 `/app/output/`：

| 文件 | 内容 |
|---|---|
| `methods.md` | 目标章节：方法步骤 / 实验设置 / 参数 / 数据 / 对照 / 复现与限制 |
| `params.csv` | 参数台账：`key,value,unit,source,source_locator,status` |
| `repro.md` | 复现清单（九项）与缺口 |
| `audit.json` | 参数与清单的核对结果（供 `result.json` 引用） |
| `result.json` | 契约字段 `case_id` + `status` + `metrics`，由 `scripts/run.py` 按 audit/repro 产出 |

## 3. 流程

**第 1 步 建别名表（你判断，必须来自材料）**
`work/params.json`：
```json
{"params":[{"key":"learning_rate","aliases":["学习率","lr"],"unit":""},
           {"key":"batch_size","aliases":["批大小","batch"],"unit":""},
           {"key":"seed","aliases":["随机种子","seed"],"unit":""}]}
```
别名只收材料里真实出现的写法，不要为凑数造同义词。

**第 2 步 抽来源、抽正文、对齐（脚本）**
```
python scripts/param_align.py --draft work/methods.md --params work/params.json \
  --sources work/config.yaml work/train.log work/model.py --out /app/output
```
判定：

| status | 条件 | 处理 |
|---|---|---|
| `sourced` | 正文值与来源一致 | 保留，写 `source_locator`（file:line） |
| `unsourced` | 正文有值，来源里找不到 | **必须删掉或标"待作者确认"，不许留成事实** |
| `conflict` | 正文值与来源不同 | 以来源为准改写正文；若来源本身冲突，列出两处并标"待确认" |
| `omitted` | 来源有、正文没写 | 关键参数（学习率/批量/种子/数据版本）必须补进正文 |

**第 3 步 写步骤与清单（你写）**
每个步骤写成表：`步骤 / 输入 / 操作 / 输出 / 判断条件`。多步操作压成一句是主要失分点。
复现九项：代码版本、运行环境（OS/驱动/CUDA 或 Python 版本）、依赖与版本、硬件、数据获取方式、数据版本与划分、随机种子、启动命令、预计轮次/耗时。

**第 4 步 核对清单与步骤（脚本）**
```
python scripts/repro_check.py --manifest work/manifest.json --steps work/steps.json \
  --params /app/output/params.csv --out /app/output
```
硬门槛：

| 指标 | 门槛 |
|---|---|
| 有源参数率 | = 1.00（正文参数全部 `sourced`） |
| 无源数值数 | = 0 |
| 冲突值数 | = 0（或全部转"待确认"） |
| 复现九项覆盖 | = 1.00 |
| 步骤四要素完整率 | = 1.00 |
| 限制条件具体率 | = 1.00（每条限制含条件/数值/失效场景，不是套话） |

**第 5 步 回填**
按 `audit.json` 的 `violations` 改：补来源、删无源值、补清单字段、把限制写到具体失效条件。

## 4. 预算与降级

64 请求 / 900 秒。顺序：读材料（0 请求）→ 建别名（1）→ 抽对齐（脚本）→ 写章节（2–3）→ 核对（脚本）→ 回填（1–2）。
`scripts/run.py --input /input --output /app/output` 是平台入口，status 由产物判定（audit.pass 且 repro.pass 才 success；无来源文件 cannot_determine；缺方法/参数 rejected）。材料只给一半时交付 `partial`，在 `result.json` 列出"缺配置文件/缺日志/缺数据说明"，**不补造数值**。

## 5. 异常

| 情况 | 处置 |
|---|---|
| 配置与日志数值不一致 | 两处都列，标 `conflict`，正文用"待确认"占位 |
| 只有代码默认值、无运行配置 | 用代码默认值但注明"默认值，实际运行配置未提供" |
| 数据集版本不明 | 只写名称与规模，版本标"未提供" |
| 随机种子未固定 | 在限制里写"结果不可逐位复现" |
| 参数无单位 | `unit` 留空并在 `params.csv` 备注，不猜单位 |

## 6. 自检

```
python examples/selftest.py
```
要求：正例六项全过；注入四类缺陷（正文改值造成冲突、删清单字段、步骤缺判断、正文凭空加温度）全部命中。
